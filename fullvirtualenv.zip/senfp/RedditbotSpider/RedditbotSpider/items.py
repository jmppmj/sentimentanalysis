# -*- coding: utf-8 -*-

# Define the models for your scraped items here

from scrapy.item import Item, Field
import scrapy


class RedditscrapyItem(scrapy.Item):
#define the fields for your item here like:
#name = scrapy.Field()
 
    pass
